#!/bin/bash
# author:tracyone,tracyone@live.cn
apt-get update  -y
apt install libpango1.0-dev -y

if [[ `uname` == 'Darwin' ]]; then
  # MacOS
  font_dir="$HOME/Library/Fonts/"
else
  # Linux
  font_dir="${HOME}/.fonts/"
  mkdir -p $font_dir
  mkdir -p /usr/share/fonts/MyFonts
  find . -regextype posix-egrep -iregex '.*\.tt[cf]$' -exec cp {} /usr/share/fonts/MyFonts  \;
fi

echo "Install start..."
find . -regextype posix-egrep -iregex '.*\.tt[cf]$' -exec cp {} ${font_dir}  \;
fc-cache -f -v

# Get the matplotlib font directory using python
FONT_DIR=$(python -c "import matplotlib; print(matplotlib.matplotlib_fname().replace('matplotlibrc', 'fonts'))")

# Check if the font directory exists
if [ ! -d "$FONT_DIR" ]; then
  echo "Error: Matplotlib font directory not found: $FONT_DIR"
  exit 1
fi

# Copy the simhei.ttf font file to the matplotlib font directory
cp simhei.ttf "$FONT_DIR"

# Remove the matplotlib cache directory
rm -rf ~/.cache/matplotlib

echo "Font installation complete."
echo "Please restart your Python environment or kernel for the changes to take effect."

echo "Install finish..."

